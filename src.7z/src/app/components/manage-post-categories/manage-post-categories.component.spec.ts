import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ManagePostCategoriesComponent } from './manage-post-categories.component';

describe('ManagePostCategoriesComponent', () => {
  let component: ManagePostCategoriesComponent;
  let fixture: ComponentFixture<ManagePostCategoriesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ManagePostCategoriesComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ManagePostCategoriesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

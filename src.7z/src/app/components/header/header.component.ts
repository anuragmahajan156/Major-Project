import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {
  role:any=sessionStorage.getItem("role");

  constructor() { }

  isLogged(){
    if(sessionStorage.getItem("role")==="undefined" || sessionStorage.getItem("role")=== ""){
    return false;
    }
    else{
    return true;
    }
  }
    roleCheck(){
    if(sessionStorage.getItem("role")==="Admin")
    {return true;}
    else{
    return false;
    }
  }

  ngOnInit(): void {

  }

}

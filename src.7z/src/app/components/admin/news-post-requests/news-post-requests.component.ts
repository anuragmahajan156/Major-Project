import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-news-post-requests',
  templateUrl: './news-post-requests.component.html',
  styleUrls: ['./news-post-requests.component.scss']
})
export class NewsPostRequestsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

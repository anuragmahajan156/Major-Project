import { ComponentFixture, TestBed } from '@angular/core/testing';

import { NewsPostRequestsComponent } from './news-post-requests.component';

describe('NewsPostRequestsComponent', () => {
  let component: NewsPostRequestsComponent;
  let fixture: ComponentFixture<NewsPostRequestsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ NewsPostRequestsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(NewsPostRequestsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

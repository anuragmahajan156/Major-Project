import { Component, OnInit } from '@angular/core';
import {HttpClient } from '@angular/common/http';
@Component({
  selector: 'app-all-news',
  templateUrl: './all-news.component.html',
  styleUrls: ['./all-news.component.scss']
})
export class AllNewsComponent implements OnInit {
  news:any
  constructor(private httpService:HttpClient) { }

  ngOnInit(): void {
    this.httpService.get('http://localhost:5000/api/News').subscribe(
      data=>(this.news=data as string[])
    )
  }
}

import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminPendingNewsRequestsComponent } from './admin-pending-news-requests.component';

describe('AdminPendingNewsRequestsComponent', () => {
  let component: AdminPendingNewsRequestsComponent;
  let fixture: ComponentFixture<AdminPendingNewsRequestsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AdminPendingNewsRequestsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AdminPendingNewsRequestsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

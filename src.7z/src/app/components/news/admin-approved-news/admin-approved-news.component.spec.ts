import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminApprovedNewsComponent } from './admin-approved-news.component';

describe('AdminApprovedNewsComponent', () => {
  let component: AdminApprovedNewsComponent;
  let fixture: ComponentFixture<AdminApprovedNewsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AdminApprovedNewsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AdminApprovedNewsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

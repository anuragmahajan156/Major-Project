import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-unapproved',
  templateUrl: './unapproved.component.html',
  styleUrls: ['./unapproved.component.scss']
})
export class UnapprovedComponent implements OnInit {

  news:any;
  users:any;
  approveNewsId:any;
  approveUserId:any;
  approveNewsValue={newsApproved:1}
  approveUserValue={approved:1}
  rejectNewsValue={newsApproved:-1}
  rejectUserValue={approved:-1}
  _newsApproveURL="http://localhost:5000/updateNewsApproved/"
  _userApproveUrl="http://localhost:5000/updateUserApproveUser/"
  constructor(private httpService:HttpClient) { }


  ngOnInit(): void {

    this.httpService.get('http://localhost:5000/UnApprovedNews').subscribe(
      data=>(this.news=data as string[])
    )

    this.httpService.get('http://localhost:5000/UnApprovedUser').subscribe(
      data=>(this.users=data as string[])
    )
  }

  updateNewsApproveValue(){
    return this.httpService.put<any>(this._newsApproveURL+this.approveNewsId,this.approveNewsValue)
  }

  ApproveNews(approveId:any){
    this.approveNewsId=approveId;
    this.updateNewsApproveValue().subscribe();
  }

  updateUserApproveValue(){
    return this.httpService.put<any>(this._userApproveUrl+this.approveUserId,this.approveUserValue)
  }

  ApproveUser(approveuserId:any){
    this.approveUserId=approveuserId;
    this.updateUserApproveValue().subscribe();
  }

  updateNewsRejectValue(){
    return this.httpService.put<any>(this._newsApproveURL+this.approveNewsId,this.rejectNewsValue)
  }

  RejectNews(approveId:any){
    this.approveNewsId=approveId;
    this.updateNewsRejectValue().subscribe();
  }

  updateUserRejectValue(){
    return this.httpService.put<any>(this._userApproveUrl+this.approveUserId,this.rejectUserValue)
  }

  RejectUser(approveuserId:any){
    this.approveUserId=approveuserId;
    this.updateUserRejectValue().subscribe();
  }

}

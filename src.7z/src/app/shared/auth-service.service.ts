import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http'
import { Router } from '@angular/router'
@Injectable({
  providedIn: 'root'
})
export class AuthServiceService {

  private _loginUrl = "http://localhost:5000/api/Authenticate/login";
  private _registerUrl = "http://localhost:5000/api/Authenticate/register";

  constructor(private http: HttpClient,
    private _router: Router) { }

    loginUser(user:any) {
      return this.http.post<any>(this._loginUrl, user)
    }

    logoutUser() {
      sessionStorage.removeItem('token')
      this._router.navigate(['/'])
    }

    getToken() {
      return sessionStorage.getItem('token')
    }

    getRole(){
      return sessionStorage.getItem('role')
    }

    getUserId(){
      return sessionStorage.getItem('id')
    }

    loggedIn() {
      return !!sessionStorage.getItem('token')
    }

    registerUser(user: {}) {
    return this.http.post<any>(this._registerUrl, user)
  }
}

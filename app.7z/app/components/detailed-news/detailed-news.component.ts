import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { AuthServiceService } from 'src/app/shared/auth-service.service';

@Component({
  selector: 'app-detailed-news',
  templateUrl: './detailed-news.component.html',
  styleUrls: ['./detailed-news.component.scss']
})
export class DetailedNewsComponent implements OnInit {
  user:any;
  _profileUrl="http://localhost:5000/api/User/"
  news:any;
  newsId:any;
  constructor(private activer:ActivatedRoute,private httpService:HttpClient,private _auth:AuthServiceService) {

    activer.params.subscribe(p=>this.newsId=p['id']);

    this.httpService.get("http://localhost:5000/api/News/"+this.newsId).subscribe(
      data=>(this.news=data as string[])
    )
    this.httpService.get(this._profileUrl+this._auth.getUserId()).subscribe(
      data=>(this.user=data as string[])
    )
   }

  ngOnInit(): void {
  }

}

import { Component, OnInit } from '@angular/core';

import { AuthServiceService } from '../../shared/auth-service.service';
import { Router } from '@angular/router'

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.scss']
})
export class SignupComponent implements OnInit {
  registerUserData = {username: "", password: "", email: "", name: "", dateOfJoining: Date(), gender: "", address: "", approved: 0};

  constructor(private _auth: AuthServiceService,
              private _router: Router) { }

  ngOnInit() {
  }

  registerUser() {
    console.log(this.registerUserData);
    this._auth.registerUser(this.registerUserData)
    .subscribe(
      (      res: { token: string; }) => {
        localStorage.setItem('token', res.token)
       // this._router.navigate(['/special'])

       console.log("Inside register" + res.token);
      },
      (      err: any) => console.log(err)
    )
  }


}


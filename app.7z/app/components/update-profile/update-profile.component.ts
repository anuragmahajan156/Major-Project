import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { AuthServiceService } from 'src/app/shared/auth-service.service';

@Component({
  selector: 'app-update-profile',
  templateUrl: './update-profile.component.html',
  styleUrls: ['./update-profile.component.scss']
})
export class UpdateProfileComponent implements OnInit {

  userName={name:""}
  userEmail={email:""}
  userUserName={userName:""}

  _updateUrl="http://localhost:5000";

  constructor(private _auth:AuthServiceService,private httpService:HttpClient) { }

  ngOnInit(): void {
  }

  updatename(){
    return this.httpService.put<any>(this._updateUrl+"/updateName/"+this._auth.getUserId(),this.userName)
  }
  updateNameOfUser(){
      this.updatename().subscribe();
      console.log(this.userName);
  }

  updateEmail(){
    return this.httpService.put<any>(this._updateUrl+"/updateEmail/"+this._auth.getUserId(), this.userEmail)
  }
  updateEmailOfUser(){
      this.updateEmail().subscribe();
  }

  updateUserName(){
    return this.httpService.put<any>(this._updateUrl+"/updateUserName/"+this._auth.getUserId(), this.userUserName)
  }
  updateUserNameOfUser(){
      this.updateUserName().subscribe();
  }
}

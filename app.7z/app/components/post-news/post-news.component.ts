import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { AuthServiceService } from 'src/app/shared/auth-service.service';

@Component({
  selector: 'app-post-news',
  templateUrl: './post-news.component.html',
  styleUrls: ['./post-news.component.scss']
})
export class PostNewsComponent implements OnInit {

  dateTime=new Date()
  postNewsData={title:"",location:"",subject:"",description:"",category:"",dateOfPost:this.dateTime,newsApproved:0,userId:this._auth.getUserId()}

  _postUrl="http://localhost:5000/api/News"

  constructor(private _auth:AuthServiceService,private httpService:HttpClient) { }

  postUserNews(news: {}) {
    return this.httpService.post<any>(this._postUrl, news)
  }
  postNews(){
    this.postUserNews(this.postNewsData).subscribe();
    console.log(this.postNewsData);
  }
  ngOnInit(): void {
  }

}

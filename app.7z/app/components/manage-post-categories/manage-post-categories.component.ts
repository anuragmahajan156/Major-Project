import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-manage-post-categories',
  templateUrl: './manage-post-categories.component.html',
  styleUrls: ['./manage-post-categories.component.scss']
})
export class ManagePostCategoriesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

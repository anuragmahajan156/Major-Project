import { Component, Input, OnInit } from '@angular/core';
import { AuthServiceService } from '../../shared/auth-service.service';
import { Router } from '@angular/router'
import { HttpClient } from '@angular/common/http';
import {FormArray, FormBuilder, FormGroup, Validators} from '@angular/forms';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {
  user:any;
  approved:any;
  static data:any;

  loginForm: FormGroup = {} as FormGroup;
  errorMessage: string = '';

  _profileUrl="http://localhost:5000/api/User/"
  //@Input() loginUserData : {username: string, password: string}

   loginUserData = {username: "", password: ""};
  constructor(private formBuilder: FormBuilder, private _auth: AuthServiceService,
              private _router: Router,private httpService:HttpClient) { }

  ngOnInit(): void {
    //this.buildForm();
  }

  // buildForm() {
  //   this.loginForm = this.formBuilder.group({
  //     email:      ['', [ Validators.required, ValidationService.emailValidator ]],
  //     password:   ['', [ Validators.required, ValidationService.passwordValidator ]]
  //   });
  // }
  loginUser () {
    this._auth.loginUser(this.loginUserData)
    .subscribe(
      (res: { token: any; id: any, role: any,value:any}) => {
        sessionStorage.setItem('token', res.token)
        sessionStorage.setItem('role', res.role)
        sessionStorage.setItem('id', res.id)
        if(res.value==1){
        this._router.navigate(['/'])
        }
        else if(res.value==-1){
          console.log("Your request has been rejected")
        }
        else{
          console.log("Your request is pending")
        }
        console.log(res.token);
        console.log(res.id);
        console.log(res.role);
        console.log(res.value);
      }
    ,
      (err: any) => console.log(err)
    )
  }
  // profileForm = this.fb.group({
  //   userName: ['', Validators.required, ],
  //   password: ['',Validators.required]
  //   });

  // constructor(private fb: FormBuilder) { }

  // updateProfile() {
  //   this.profileForm.patchValue({
  //     firstName: 'Nancy',
  //     address: {
  //       street: '123 Drew Street'
  //     }
  //   });
  // }

  // onClick() {
  //   // TODO: Use EventEmitter with form value
  //   console.warn(this.profileForm.value);
  // }
  //
  // ngOnInit(): void {
  // }
  // validateName(){
  //
  // }
}



import { Component, OnInit } from '@angular/core';
import {AuthServiceService} from "../../shared/auth-service.service";
import {Router} from "@angular/router";

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {
  role:any=sessionStorage.getItem("role");

  constructor(private _auth: AuthServiceService, private _router: Router) { }

  isLogged(){
    if(sessionStorage.getItem("role")==="undefined" || sessionStorage.getItem("role")=== ""){
    return false;
    }
    else{
    return true;
    }
  }
    roleCheck(){
    if(sessionStorage.getItem("role")==="Admin")
    {return true;}
    else{
    return false;
    }
  }

 userLogOut(){
   this._auth.logoutUser();
   sessionStorage.clear();
   localStorage.clear();
 }

  ngOnInit(): void {

  }

}

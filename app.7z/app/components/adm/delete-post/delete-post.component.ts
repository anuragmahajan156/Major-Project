import { Component, OnInit } from '@angular/core';
import { AuthServiceService } from '../../../shared/auth-service.service';
import { Router } from '@angular/router'
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-delete-post',
  templateUrl: './delete-post.component.html',
  styleUrls: ['./delete-post.component.scss']
})
export class DeletePostComponent implements OnInit {
  postId: any;
  news:any;

  _deletePostUrl="http://localhost:5000/delete";

  constructor(private _auth:AuthServiceService,private httpService:HttpClient) { }



  deleteNewsPost(id:{}){
      return this.httpService.post<any>(this._deletePostUrl,id);
  }

  deleteNews(newsId:any){
    this.deleteNewsPost(newsId).subscribe();
    console.log(newsId);
  }
  ngOnInit(): void {

  this.httpService.get('http://localhost:5000/api/News').subscribe(
      data=>(this.news=data as string[])
    )
  }

}

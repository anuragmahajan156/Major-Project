import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-post-news',
  templateUrl: './post-news.component.html',
  styleUrls: ['./post-news.component.scss']
})
export class PostNewsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

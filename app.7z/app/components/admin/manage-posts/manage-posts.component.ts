import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-manage-posts',
  templateUrl: './manage-posts.component.html',
  styleUrls: ['./manage-posts.component.scss']
})
export class ManagePostsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

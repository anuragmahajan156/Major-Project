import { Component, OnInit } from '@angular/core';
import {AuthServiceService} from "../../../shared/auth-service.service";
import {HttpClient} from "@angular/common/http";

@Component({
  selector: 'app-admin-approved-news',
  templateUrl: './admin-approved-news.component.html',
  styleUrls: ['./admin-approved-news.component.scss']
})
export class AdminApprovedNewsComponent implements OnInit {

  user:any;
  _profileUrl="http://localhost:5000/api/User/"
  news:any;
  rejectedNews:any;
  approvedNews:any;
  Url:string="http://localhost:5000";
  constructor(private _auth:AuthServiceService,private httpService:HttpClient) {

  }

  ngOnInit(): void {
    this.httpService.get(this.Url+"/getNewsByUserId/"+this._auth.getUserId()).subscribe(
      data=>(this.news=data as string[])
    )
    this.httpService.get(this.Url+"/RejectedNews/"+this._auth.getUserId()).subscribe(
      data=>(this.rejectedNews=data as string[])
    )
    this.httpService.get(this.Url+"/ApprovedNews/"+this._auth.getUserId()).subscribe(
      data=>(this.approvedNews=data as string[])
    )
    this.httpService.get(this._profileUrl+this._auth.getUserId()).subscribe(
      data=>(this.user=data as string[])
    )
  }

}

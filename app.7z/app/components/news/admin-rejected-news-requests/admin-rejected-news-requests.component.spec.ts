import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminRejectedNewsRequestsComponent } from './admin-rejected-news-requests.component';

describe('AdminRejectedNewsRequestsComponent', () => {
  let component: AdminRejectedNewsRequestsComponent;
  let fixture: ComponentFixture<AdminRejectedNewsRequestsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AdminRejectedNewsRequestsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AdminRejectedNewsRequestsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
 import { AdminProfileComponent } from './components/admin/admin-profile/admin-profile.component';
 import { ManagePostCategoriesComponent } from './components/admin/manage-post-categories/manage-post-categories.component';
 import { ManagePostsComponent } from './components/admin/manage-posts/manage-posts.component';
 import { ManageUsersComponent } from './components/admin/manage-users/manage-users.component';
 import { MyPostsComponent } from './components/admin/my-posts/my-posts.component';
 import { NewsPostRequestsComponent } from './components/admin/news-post-requests/news-post-requests.component';
 import { RegistrationRequestsComponent } from './components/admin/registration-requests/registration-requests.component';
//  import { AsideComponent } from './components/aside/aside.component';
import { CarouselComponent } from './components/carousel/carousel.component';
import { HomeComponent } from './components/home/home.component';
import { LoginComponent } from './components/login/login.component';
import { MypostsComponent } from './components/myposts/myposts.component';
import { PostNewsComponent } from './components/post-news/post-news.component';
import { PostStatusComponent } from './components/post-status/post-status.component';
import { ProfileComponent } from './components/profile/profile.component';
import { SignupComponent } from './components/signup/signup.component';
import { AllNewsComponent } from './components/all-news/all-news.component';
import { EmployeeDashboardComponent } from './components/employee-dashboard/employee-dashboard.component';
import { AdminDashboardComponent } from './components/admin-dashboard/admin-dashboard.component';
import { UpdateProfileComponent } from './components/update-profile/update-profile.component';
import { UnapprovedComponent } from './components/unapproved/unapproved.component';
import { DetailedNewsComponent } from './components/detailed-news/detailed-news.component';
import {AdminPendingNewsRequestsComponent} from "./components/news/admin-pending-news-requests/admin-pending-news-requests.component";
import {AdminApprovedNewsComponent} from "./components/news/admin-approved-news/admin-approved-news.component";
import { DeletePostComponent } from './components/adm/delete-post/delete-post.component';


import {AdminRejectedNewsRequestsComponent} from "./components/news/admin-rejected-news-requests/admin-rejected-news-requests.component";
const routes: Routes = [
{path:"",component:HomeComponent,
children:[
 { path:"",component:CarouselComponent},
//  { path:"aside",component:AsideComponent},
 { path:"profile",component:ProfileComponent},
 { path:"postNews",component:PostNewsComponent},
 { path:"poststatus",component:PostStatusComponent},
 { path:"myposts",component:MypostsComponent},
  {path: "adminPendingNewsRequests", component: AdminPendingNewsRequestsComponent},
  {path: "adminApprovedNews", component: AdminApprovedNewsComponent},
    {path:"deletePosts",component:DeletePostComponent},
  {path: "adminRejectedNews", component: AdminRejectedNewsRequestsComponent}
]},
{path:"Admin",component:AdminProfileComponent,
children:[
  {path:"managecategories",component:ManagePostCategoriesComponent},
  {path:"managepost",component:ManagePostsComponent},
  {path:"manageuser",component:ManageUsersComponent},
  {path:"mypost",component:MyPostsComponent},
  {path:"postnews",component:PostNewsComponent},
  {path:"registrationrequest",component:RegistrationRequestsComponent},
  {path:"newpostrequest",component:NewsPostRequestsComponent},


]},


{path:"login",component:LoginComponent},
{path:"signup",component:SignupComponent},
{path:"allNews",component:AllNewsComponent},
{path:"myDashBoardEmployee",component:EmployeeDashboardComponent},
{path:"myDashBoardAdmin",component:AdminDashboardComponent},
{path:"postnews",component:PostNewsComponent},
{path:"updateProfile",component:UpdateProfileComponent},
{path:"unapproved",component:UnapprovedComponent},
{path:"detailedNews/:id",component:DetailedNewsComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]

})
export class AppRoutingModule { }

import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MdbAccordionModule } from 'mdb-angular-ui-kit/accordion';
import { MdbCarouselModule } from 'mdb-angular-ui-kit/carousel';
import { MdbCheckboxModule } from 'mdb-angular-ui-kit/checkbox';
import { MdbCollapseModule } from 'mdb-angular-ui-kit/collapse';
import { MdbDropdownModule } from 'mdb-angular-ui-kit/dropdown';
import { MdbFormsModule } from 'mdb-angular-ui-kit/forms';
import { MdbModalModule } from 'mdb-angular-ui-kit/modal';
import { MdbPopoverModule } from 'mdb-angular-ui-kit/popover';
import { MdbRadioModule } from 'mdb-angular-ui-kit/radio';
import { MdbRangeModule } from 'mdb-angular-ui-kit/range';
import { MdbRippleModule } from 'mdb-angular-ui-kit/ripple';
import { MdbScrollspyModule } from 'mdb-angular-ui-kit/scrollspy';
import { MdbTabsModule } from 'mdb-angular-ui-kit/tabs';
import { MdbTooltipModule } from 'mdb-angular-ui-kit/tooltip';
import { MdbValidationModule } from 'mdb-angular-ui-kit/validation';
import { HeaderComponent } from './components/header/header.component';
import { FooterComponent } from './components/footer/footer.component';
import { LoginComponent } from './components/login/login.component';
import { SignupComponent } from './components/signup/signup.component';
import { PagenotfoundComponent } from './components/pagenotfound/pagenotfound.component';
import { PostNewsComponent } from './components/post-news/post-news.component';
import { ProfileComponent } from './components/profile/profile.component';
import { MypostsComponent } from './components/myposts/myposts.component';
import { PostStatusComponent } from './components/post-status/post-status.component';
import { CarouselComponent } from './components/carousel/carousel.component';
import { HomeComponent } from './components/home/home.component';
import { AdminProfileComponent } from './components/admin/admin-profile/admin-profile.component';
import { ManagePostCategoriesComponent } from './components/manage-post-categories/manage-post-categories.component';

import { MainComponent } from './components/main/main.component';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { TokenInterceptorService } from './shared/token-interceptor.service';
import { AuthServiceService } from './shared/auth-service.service';
import { ReactiveFormsModule } from '@angular/forms';
import { AllNewsComponent } from './components/all-news/all-news.component';
import { EmployeeDashboardComponent } from './components/employee-dashboard/employee-dashboard.component';
import { UpdateProfileComponent } from './components/update-profile/update-profile.component';
import { AdminDashboardComponent } from './components/admin-dashboard/admin-dashboard.component';
import { UnapprovedComponent } from './components/unapproved/unapproved.component';
import { DetailedNewsComponent } from './components/detailed-news/detailed-news.component';
import { SidebarComponent } from './components/sidebar/sidebar.component';
import { AdminApprovedNewsComponent } from './components/news/admin-approved-news/admin-approved-news.component';
import { AdminPendingNewsRequestsComponent } from './components/news/admin-pending-news-requests/admin-pending-news-requests.component';
import { AdminRejectedNewsRequestsComponent } from './components/news/admin-rejected-news-requests/admin-rejected-news-requests.component';
import { DeletePostComponent } from './components/adm/delete-post/delete-post.component';


@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    FooterComponent,
    LoginComponent,
    SignupComponent,
    PagenotfoundComponent,
    PostNewsComponent,
    ProfileComponent,
    MypostsComponent,
    PostStatusComponent,
    CarouselComponent,
    HomeComponent,
    AdminProfileComponent,
    ManagePostCategoriesComponent,
    MainComponent,
    AllNewsComponent,
    EmployeeDashboardComponent,
    UpdateProfileComponent,
    AdminDashboardComponent,
    UnapprovedComponent,
    DetailedNewsComponent,
    SidebarComponent,
    AdminApprovedNewsComponent,
    AdminPendingNewsRequestsComponent,
    AdminRejectedNewsRequestsComponent,
  DeletePostComponent

  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    MdbAccordionModule,
    MdbCarouselModule,
    MdbCheckboxModule,
    MdbCollapseModule,
    MdbDropdownModule,
    MdbFormsModule,
    MdbModalModule,
    MdbPopoverModule,
    MdbRadioModule,
    MdbRangeModule,
    MdbRippleModule,
    MdbScrollspyModule,
    MdbTabsModule,
    MdbTooltipModule,
    MdbValidationModule,
    FormsModule,
    HttpClientModule,
    ReactiveFormsModule
  ],
  providers: [AuthServiceService,
    {
      provide: HTTP_INTERCEPTORS,
      useClass: TokenInterceptorService,
      multi: true
    }],
  bootstrap: [AppComponent]
})
export class AppModule { }
